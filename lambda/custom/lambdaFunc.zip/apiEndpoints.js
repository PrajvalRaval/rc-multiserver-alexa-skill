/* eslint-disable no-dupe-keys */
// const envVariables = require('./config');

// REST API Endpoints

module.exports = {
	postmessageurl: '/api/v1/chat.postMessage',
};
