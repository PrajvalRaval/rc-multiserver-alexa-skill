// Environment Variables

module.exports = {
	serverurl: process.env.SERVER_URL,
	proxyurl: process.env.MULTISERVERPROXY_URL,
	oauthServiceName: process.env.OAUTH_SERVICE_NAME,
	dynamoDBTableName: process.env.DDB_NAME,
};
